"""Speech to text."""
