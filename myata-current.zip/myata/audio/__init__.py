"""Microphone input."""
